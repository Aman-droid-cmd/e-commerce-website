


<h1>Hello Every One</h1>
<?php

$get =$_GET['name'];

echo "hell fello".$get ;

?>
