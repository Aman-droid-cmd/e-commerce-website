-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2020 at 10:32 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshoppers`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` varchar(222) NOT NULL,
  `description` varchar(244) NOT NULL,
  `image` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`) VALUES
(18, 'T-shirt ', '99 Rs', 'For both man and women wear with trouser for best Appearence', 'images/shop/9 T-shirt .jpg'),
(19, 'Blaser For Girl', '9999 Rs', 'For women wear with Jeans for best Appearence it look quite appealing', 'images/shop/10 Blaser For Girl.jpg'),
(20, 'coke ', '59 Rs', 'Chill Pill Summer Kill ,Winter Alive', 'images/shop/11 coke .jpg'),
(21, 'Hanger', '54 Rs', 'For clothes', 'images/shop/12 Hanger.jpg'),
(22, 'Sun Glass', '956 Rs', 'For harsh Sunlight', 'images/shop/13 Sun Glass.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `mobile` varchar(244) NOT NULL,
  `password` varchar(255) NOT NULL,
  `cpassword` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `username`, `email`, `mobile`, `password`, `cpassword`) VALUES
(6, 'kaif4', 'kaifk468@gmail.conm', '7408001310', '$2y$10$3uJCMKZuxcLgukG4kJDnzObcKdLB07DoD82M9', '$2y$10$LLfPV43orpw01owsRdgpY.iuckcHABClOjdnlOCbA6ellb8/6w.EK'),
(7, 'admin', 'jalebi@bai.nach', '7408001310', '$2y$10$TB.ToWLXQGMqLEl9S7bN8ebELMdN6Pe9awUtO', '$2y$10$vdV86deiECW0LCT00Q7jxeETusixoqDlmleGvq5BjfiCt0QXK.7Zy'),
(13, 'admin', 'gaifk468@gmail.com', '7408001310', '$2y$10$tRBcuufMdSzcWPXD4jXoo.UCF2AlQf1oq1F3qdYpH6S5NLo4dPWT6', '$2y$10$FsK6z2yubLMVIy.nnivo8e1C/cCmdigT1mC2aKBzpzWI/jACWi2Aa'),
(14, 'admin', 'admin@gmail.com', '6408001310', '$2y$10$HOxOC28ZJa5srMFAJHzz.Ok9J3Lzw8zomCZdTVvWKsFH7jU3HoX8W', '$2y$10$bcHjHZPipn7vs6/36Ngm2ePW3irJIWBLvOuUf6ot5eRvz2lnm5G0W');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
