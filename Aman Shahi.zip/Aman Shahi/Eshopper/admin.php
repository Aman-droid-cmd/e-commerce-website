<?php include'conn.php' ?>
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
   
      <div class="container align-center">
         <div class="row text-center text-primary"><h2>Admin Dashboard</h2></div>
          <div class="row">
       <form  action="viewproduct.php" method="POST">
           <button type="submit"class="btn-success" name="psubmit">View Your Products</button>
       </form >
   </div>
      </div><br>
    <section>
    <div class="row">
        <div class="col-6 offset-2">
        <?php 
    if(isset($_POST['submit'])) {
        $p_name = $_POST['name'];
        $price = $_POST['price'];
        $description = $_POST['description'];

        $productquery = "select * from products order by id ASC " ;
        $query = mysqli_query($con,$productquery);
        $num =mysqli_num_rows($query);
        $count = $num + 1;

        $name = "{$count} ".$_POST['name'];
        $target_dir = "images/shop/";
        $uploadOk = 1;
        $imageFileType = pathinfo( basename($_FILES["fileToUpload"]["name"]),PATHINFO_EXTENSION);
        $target_file = $target_dir .$name.".$imageFileType";
        // Check if image file is a actual image or fake image
        
            if(empty($_FILES["fileToUpload"]["name"])){
            echo 'please select an image';
            header('location:admin.php');
        }
            $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
            if($check !== false) {
                // echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
         
        /*if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }*/
        // Check file size
        if ($_FILES["fileToUpload"]["size"] > 10000000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
           if (file_exists($target_file)) {   
           unlink($target_file);
            } 
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
                $sql="INSERT INTO products(name, price, description, image) values('$p_name', '$price', '$description', '$target_file')";
                if(mysqli_query($con, $sql)){
                     $info = getimagesize($target_file); 
                    if ($info['mime'] == 'image/jpeg' || $info['mime'] == 'image/JPEG') $image = imagecreatefromjpeg($target_file); 
                    elseif ($info['mime'] == 'image/gif' || $info['mime'] == 'image/GIF') $image = imagecreatefromgif($target_file); 
                    elseif ($info['mime'] == 'image/png' || $info['mime'] == 'image/PNG') $image = imagecreatefrompng($target_file); 
                    elseif ($info['mime'] == 'image/jpg' || $info['mime'] == 'image/JPG') $image = imagecreatefromjpeg($target_file); 
                    imagejpeg($image, $target_file, 10);
        
                }else{
                    echo 'Error adding to database';
                }        
                
                
            } else {
                echo "<p>Sorry, there was an error uploading your file.</p>";
            }
        }
        echo "<h3>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspSuccess</h3>";
        }
        
?>   </div>
    </div>
    </section> 
    
   <section id="form" class="mt-5 mb-5"><!--form-->
		<div class="container">
			<div class="row">
				<div class="col-sm-8 col-sm-offset-2">
					<div class="login-form"><!--login form-->
						<h2 class="text-primary">Welcome To Dashboard</h2>
			
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" method="POST" enctype="multipart/form-data">
            
                <label for="name">Name</label><input type="text" name='name'/>
                <label for="price">Price</label><input type="text" name='price'/>
                <label for="description">Description</label><input type="text" name='description'/>
                <label for="image">Poduct Image</label><input type="file" name='fileToUpload' id="fileToUpload"/>
                                                       <input type="submit" class="btn btn-success" name="submit" value="Submit">     
        </form>
        <div class="text-center"><p>Log In as User ?? <a href="login.php">Log In</a></p></div>
        </div><!--/login form-->
				</div>
			
			</div>
		</div>
	</section><!--/f
    
<?php include'includes/footer.php' ?>