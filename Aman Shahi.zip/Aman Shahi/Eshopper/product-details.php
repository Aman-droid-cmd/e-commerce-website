<?php include'session.php'; ?>
<?php include'includes/header.php' ?>

<?php 
   
    $get = $_GET['name'];
    $prodetailquery ="select * from products where id='$get'";
    $prodelquery = mysqli_query($con,$prodetailquery);
    $prodetarray =mysqli_fetch_array($prodelquery);
    $prodetrow = mysqli_num_rows($prodelquery);
    


?>
	
	<section>
		<div class="container">
			<div class="row">
				
				
				<div class="col-sm-12 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
								<img src="<?php echo $prodetarray['image']; ?>" alt="" />
								
							</div>
							<div id="similar-product" class="carousel slide" data-ride="carousel">
								
								  <!-- Wrapper for slides -->
								    <div class="carousel-inner">
										<div class="item active">
										  <a href=""><img src="images/product-details/similar1.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar2.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar3.jpg" alt=""></a>
										</div>
										<div class="item">
										  <a href=""><img src="images/product-details/similar1.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar2.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar3.jpg" alt=""></a>
										</div>
										<div class="item">
										  <a href=""><img src="images/product-details/similar1.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar2.jpg" alt=""></a>
										  <a href=""><img src="images/product-details/similar3.jpg" alt=""></a>
										</div>
										
									</div>

								  <!-- Controls -->
								  <a class="left item-control" href="#similar-product" data-slide="prev">
									<i class="fa fa-angle-left"></i>
								  </a>
								  <a class="right item-control" href="#similar-product" data-slide="next">
									<i class="fa fa-angle-right"></i>
								  </a>
							</div>

						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
								<img src="images/product-details/new.jpg" class="newarrival" alt="" />
								<h2><?php echo $prodetarray['name'] ;?></h2>
								<img src="images/product-details/rating.png" alt="" />
								<span>
									<span><?php echo $prodetarray['price']; ?></span>
									<label>Quantity:</label>
									<form action="cart.php" method="POST">
										    <input type="submit" name="addtocart" class="btn btn-warning form-control" value="Add to Cart">
										    <span>Quantity</span><input type="number" value="1" min="1" max="5" style="margin-top:5px; 
										    margin-bottom:5px; margin-left:4px; border-radius:6px" name="quantity">
										    <input type="hidden" value="<?php echo $prodetarray['price']; ?>" name="price">
										    <input type="hidden" value="<?php echo $prodetarray['image']; ?>" name="image">
										    <input type="hidden" value="<?php echo $prodetarray['name']; ?>" name="name">
										    <input type="hidden" value="<?php echo $prodetarray['id']; ?>" name="id">
										    
										</form>
								</span>
								<p><b>Availability:</b> In Stock</p>
								<p><b>Condition:</b> New</p>
								<a href=""><img src="images/product-details/share.png" class="share img-responsive"  alt="" /></a>
								<div><h1>Description</h1>
								    <h3><strong><?php echo $prodetarray['description']; ?></strong></h3>
								</div>
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
					
					
					

					
				</div>
			</div>
		</div>
	</section>
	
<?php include'includes/footer.php' ?>