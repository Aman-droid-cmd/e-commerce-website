<?php  
  session_start();

unset($_SESSION['displayname']);
header('location:login.php');

 
?>