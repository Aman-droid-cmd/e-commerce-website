<?php 
include'includes/header.php';


     
     $prodquery = "select * from products ";
     $query = mysqli_query($con,$prodquery);
     $rows = mysqli_num_rows($query);
     
 
     echo '<div class="row text-center text-danger "><h2>Your Feature Products</h2></div>' ;
     echo '<section id="cart_items">
		<div class="container">
			<div class="breadcrumbs">
				<ol class="breadcrumb">
				  <li><a href="#">Home</a></li>
				  <li class="active">Shopping Cart</li>
				</ol>
			</div>' ;
     echo '<div class="table-responsive cart_info">
				<table class="table table-condensed">
					<thead>
						<tr class="cart_menu">
							<td class="image">Item</td>
							<td class="price">Price</td>
                            <td class="description">description</td>
                            <td class="description">Delete</td>
						</tr>
					</thead>
					<tbody>' ;
     
     
     
     if($rows > 0)
     {
         while($prodarray = mysqli_fetch_array($query))
         {
             echo '<tr>' ;
             echo '<td  class="t">
								<a href=""><img width=110px height=110px src=" '.$prodarray["image"].'" alt=""></a>
							</td>' ;
             echo '<td  class="t">
								<strong class"text-success">'.$prodarray["price"].'</strong>
							</td>' ;
             echo '<td  class="t">
								<strong class"text-success">'.$prodarray["description"].'</strong>
							</td>' ;
             echo '<td  class="t">
								<a href="admindelete.php?id='.$prodarray["id"].'" class="btn"><button class="btn"> Delete </button> </a>
							</td>' ;
             echo '</tr>' ;
      
         }
     }
     echo '		</tbody>
				</table>
			</div>
		</div>
	
		    <div style="align-item:center">
		        <button class="btn btn-success btn-block.">Check Out</button>
		    </div>
	</section>';
 

?>


