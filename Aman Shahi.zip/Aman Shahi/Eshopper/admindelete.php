<?php include'conn.php' ;
 
$id = $_GET['id'];

$deletequery = "delete from products where id = $id ";
$deleteq = mysqli_query($con,$deletequery);


?>
<script>
   location.replace('viewproduct.php');
</script>