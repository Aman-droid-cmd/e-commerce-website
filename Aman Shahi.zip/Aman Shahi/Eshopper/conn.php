
<?php

  $user = "root";
  $password = "";
  $server = "localhost";
  $database = "eshoppers";

  $con = mysqli_connect($server,$user,$password,$database);
?>
