<?php session_start() ; ?>
<?php
if(!isset($_SESSION['displayname']))
{
  header('location:login.php');
}

?>



















































